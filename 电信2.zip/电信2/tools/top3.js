
res_log(document.cookie);